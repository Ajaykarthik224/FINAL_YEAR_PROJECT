import sys
from PyQt5 import QtCore
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

selected_state = ''


class Home(QWidget):
    def __init__(self, str):
        super().__init__()
        selected_state = str

        self.setWindowTitle("Main Window")
        self.resize(800, 400)
        self.setMaximumSize(800, 400)
        self.setMinimumSize(800, 400)
        self.setStyleSheet("background-color:#243665;")
        # add a label for displaying state
        self.label = QLabel(self)
        self.label.resize(50, 20)
        self.label.move(10, 5)
        self.label.setText("State:")
        self.label.setStyleSheet(
            "color:#8BD8BD;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")
        # add a label for state
        self.label1 = QLabel(self)
        self.label1.resize(50, 20)
        self.label1.move(60, 5)
        self.label1.setText(selected_state)
        self.label1.setStyleSheet(
            "color:#8BD8BD;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        # add a label to display prediction
        self.label2 = QLabel(self)
        self.label2.resize(100, 20)
        self.label2.move(300, 5)
        self.label2.setText("Prediction:")
        self.label2.setStyleSheet(
            "color:#8BD8BD;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        # add a label for prediction value
        self.label3 = QLabel(self)
        self.label3.resize(50, 20)
        self.label3.move(390, 5)
        self.label3.setText("Yes")
        self.label3.setStyleSheet(
            "color:#8BD8BD;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")
        # add a label to display weather
        self.label4 = QLabel(self)
        self.label4.resize(80, 20)
        self.label4.move(550, 5)
        self.label4.setText("Weather:")
        self.label4.setStyleSheet(
            "color:#8BD8BD;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")
        # add label to display value of weather
        self.label5 = QLabel(self)
        self.label5.resize(100, 20)
        self.label5.move(650, 5)
        # instead of 'data' add weather data
        self.label5.setText("data")
        self.label5.setStyleSheet(
            "color:#8BD8BD;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        # add labels
        self.label6 = QLabel(self)
        self.label6.resize(100, 30)
        self.label6.move(250, 100)
        # instead of 'data' add weather data
        self.label6.setText("Algorithm")
        self.label6.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;border:2px solid white;padding-left:10px;")

        self.label7 = QLabel(self)
        self.label7.resize(200, 30)
        self.label7.move(450, 100)
        # instead of 'data' add weather data
        self.label7.setText("Accuracy ( in % )")
        self.label7.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;border:2px solid white;padding-left:30px;")

        self.label8 = QLabel(self)
        self.label8.resize(150, 30)
        self.label8.move(250, 150)
        # instead of 'data' add weather data
        self.label8.setText("K Nearest Neighbor")
        self.label8.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        self.label9 = QLabel(self)
        self.label9.resize(150, 30)
        self.label9.move(250, 190)
        # instead of 'data' add weather data
        self.label9.setText("Logistic Regression")
        self.label9.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        self.label10 = QLabel(self)
        self.label10.resize(150, 30)
        self.label10.move(250, 230)
        # instead of 'data' add weather data
        self.label10.setText("Suppport Vector")
        self.label10.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        self.label11 = QLabel(self)
        self.label11.resize(150, 30)
        self.label11.move(250, 270)
        # instead of 'data' add weather data
        self.label11.setText("Decision Tree")
        self.label11.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        # percentage values label
        self.label8 = QLabel(self)
        self.label8.resize(150, 30)
        self.label8.move(450, 150)
        # instead of 'data' add weather data
        self.label8.setText("100%")
        self.label8.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        self.label9 = QLabel(self)
        self.label9.resize(150, 30)
        self.label9.move(450, 190)
        # instead of 'data' add weather data
        self.label9.setText("100%")
        self.label9.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        self.label10 = QLabel(self)
        self.label10.resize(150, 30)
        self.label10.move(450, 230)
        # instead of 'data' add weather data
        self.label10.setText("100%")
        self.label10.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")

        self.label11 = QLabel(self)
        self.label11.resize(150, 30)
        self.label11.move(450, 270)
        # instead of 'data' add weather data
        self.label11.setText("100%")
        self.label11.setStyleSheet(
            "color:#FFFFFF;font:15px \"Gill Sans Extrabold\",sans-serif;font-weight:bold;")
        self.show()


# app = QApplication(sys.argv)
# w = Home('Hello')
# sys.exit(app.exec_())
