import sys
from home import Home
from PyQt5 import QtCore
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

state_list = ['Kerala', 'Karnataka']

selected_state = 'Kerala'


class Window2(QWidget):
    def __init__(self):
        super().__init__()
        # Set Window Properties
        self.setWindowTitle("Select State")
        self.resize(500, 200)
        # self.setWindowFlag(Qt.FramelessWindowHint)
        self.setMaximumSize(500, 200)
        self.setMinimumSize(500, 200)
        # self.setStyleSheet("background-color:#FFFFFF;")

        # Set Label for Displaying Select State
        self.label1 = QLabel(self)
        self.label1.setText("Want to know if there is flood in your area?")
        self.label1.move(10, 40)
        self.label1.setStyleSheet(
            "font:12pt \"Courier New\", monospace; color:#344fa1;")

        self.label3 = QLabel(self)
        self.label3.setText("Please Select your state below..")
        self.label3.move(10, 70)
        self.label3.setStyleSheet(
            "font:12pt \"Courier New\", monospace; color:#344fa1;")

        # add a Label that displays the application name
        self.label2 = QLabel(self)
        self.label2.setText("Global Flood Predictor")
        self.label2.move(130, 10)
        self.label2.resize(240, 25)
        self.label2.setStyleSheet(
            "color:MidnightBlue;font:12pt \"Georgia\";font-weight:bold;padding-left:20px;")

        # add a combobox to choose states
        self.combobox = QComboBox(self)
        self.combobox.addItems(state_list)
        self.combobox.move(10, 120)
        self.combobox.resize(100, 30)
        self.combobox.activated.connect(self.selectionchange)

        # add a push button
        self.go_btn = QPushButton(self)
        self.go_btn.setText("GO")
        self.go_btn.resize(80, 30)
        self.go_btn.move(350, 120)
        self.go_btn.clicked.connect(self.on_go_btn_clicked)
        self.show()

    def close_btn_onclick(self):
        self.close()

    def eventFilter(self, object, event):
        if event.type() == QtCore.QEvent.HoverMove:
            self.btn_close.setIcon(QIcon('close_btn1_red.png'))
            return True
        return False

    def selectionchange(self, i):
        global selected_state
        selected_state = self.combobox.currentText()

    def on_go_btn_clicked(self):
        self.w = Home(selected_state)
        self.w.show()
        self.close()


# app = QApplication(sys.argv)
# w = Window2()
# sys.exit(app.exec_())
